<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layouts/backend'); ?>

<div class="panel panel-info">
    <div class="panel-heading">
        <h1 class="panel-title">
        </h1>
    </div>
    <div class="panel-body"><?php echo $content; ?></div>
</div>
<?php $this->endContent(); ?>