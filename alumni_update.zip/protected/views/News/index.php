<center>

    <i class="fa fa-envelope fa-5x"></i>

    <div class="well">
        <h2>
            ยินดีต้อนรับเข้าสู่ระบบข่าว
        </h2>
    </div>
</center>