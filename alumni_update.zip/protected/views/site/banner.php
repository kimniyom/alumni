<div class="row carousel-holder">
    <div class="col-md-12">
        <center>
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner" style="height: 300px;">

                    <div class="actrive item" style="color:#FFF;">
                        <div class="row">
                            <div class=" col-md-7 col-sm-7" style=" text-align: left;">
                                <h1 style="color:#FFF; text-shadow:2px 1px #000;">วิทยาการคอมพิวเตอร์ จบแล้วทำงานอะไร</h1>
                                <br/>
                                <div class="alert alert-success">
                                    <p style=" font-size: 18px;text-indent: 2.5em;">
                                        สาขานี้เรียนอะไร
                                        สาขาวิทยาการคอมพิวเตอร์ เป็นสาขาที่เรียนเกี่ยวกับทฤษฎีการคำนวณสำหรับคอมพิวเตอร์
                                        ทฤษฎีการประมวลผลสารสนเทศ ทั้งด้านซอฟต์แวร์ ฮาร์ดแวร์ และ เครือข่าย 
                                        ซึ่งประกอบด้วยหลายหัวข้อที่เกี่ยวข้องกับคอมพิวเตอร์.</dd>
                                    </p>
                                </div>
                            </div>
                            <div class=" col-md-5 col-sm-5">
                                <img src="<?php echo Yii::app()->baseUrl; ?>/images/devices3.png" height="250" style=" margin-top: 10px;"/>
                            </div>
                        </div>
                    </div> 

                    
                </div>
                <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>
                <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>
            </div>
        </center>
    </div>
</div>