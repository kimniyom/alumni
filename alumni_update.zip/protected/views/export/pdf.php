<?php
$_GET['GenNumber'];
?>

<table class="table">
    <thead>
        <tr>
            <th>ลำดับ</th>
            <th>รหัส</th>
            <th>ชื่อ - สกุล</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td></td>
            <td></td>
            <td></td>
        </tr>
    </tbody>
</table>