<div class="well" style="text-align: center;">
    <h1>
        <i class="fa fa-gear fa-3x" style="color: #cccccc; margin: 10px;"></i>
        <i class="fa fa-users fa-3x" style="color: #cccccc; margin: 10px;"></i>
        <i class="fa fa-edit fa-3x" style="color: #cccccc; margin: 10px;"></i>
        <br/><br/>
        ยินดีต้อนรับผู้ดูแลระบบ
    </h1>
    <br/><br/>
</div>
