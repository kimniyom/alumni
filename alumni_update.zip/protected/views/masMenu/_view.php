<?php
/* @var $this MasMenuController */
/* @var $data MasMenu */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('menu_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->menu_id), array('view', 'id'=>$data->menu_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('menu_name')); ?>:</b>
	<?php echo CHtml::encode($data->menu_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('menu_url')); ?>:</b>
	<?php echo CHtml::encode($data->menu_url); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('d_update')); ?>:</b>
	<?php echo CHtml::encode($data->d_update); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('create_by')); ?>:</b>
	<?php echo CHtml::encode($data->create_by); ?>
	<br />


</div>